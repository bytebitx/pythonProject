import tkinter as tk
from tkinter import ttk, Tk, messagebox

from gui.system.student.add_info import create_add
from gui.system.student.query_info import create_query_info


class Application(ttk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.page = None
        self.master = master
        self.create_main_page()

    def create_main_page(self):
        # 这两行非常重要，没有这两行会导致登录页面也会显示在该页面下面且可见
        self.page = ttk.Frame(self.master)
        self.page.grid(ipady=60)  # 可以不要ipady=60，写上是为了铺满整个窗口

        self.title = ttk.Label(self.page, text="信息管理系统", font=("宋体", 30))
        self.title.grid(row=0, column=1)

        self.query = ttk.Label(self.page, text="查询信息", font=("宋体", 15), background='cyan',
                               wraplength=2, width=5, anchor='center')
        self.query.grid(row=1, column=0, padx=40, rowspan=7, ipady=100, pady=20)
        self.query.bind("<Button-1>", self.query_info)

        self.add = ttk.Label(self.page, text="添加信息", font=("宋体", 15), background='green', width=30,
                             anchor='center')
        self.add.grid(row=1, column=1, ipady=20, rowspan=2, pady=20)
        self.add.bind("<Button-1>", self.add_info)

        self.delete = ttk.Label(self.page, text="删除信息", font=("宋体", 15), background='green', width=30,
                                anchor='center')
        self.delete.grid(row=3, column=1, ipady=20, rowspan=2)
        self.delete.bind("<Button-1>", self.deleteInfo)

        self.modify = ttk.Label(self.page, text="修改信息", font=("宋体", 15), background='green', width=30,
                                anchor='center')
        self.modify.grid(row=5, column=1, ipady=20, rowspan=2, pady=20)
        self.modify.bind("<Button-1>", self.modifyInfo)

        self.quite = tk.Button(self.page, text="退出", font=("宋体", 15), background='gray',
                               width=30, anchor='center', command=self.quiteSys)
        self.quite.grid(row=7, column=1, ipady=20, rowspan=2)

        self.show = ttk.Label(self.page, text="显示所有信息", font=("宋体", 15), background='cyan',
                              wraplength=2, width=5, anchor='center')
        self.show.grid(row=1, column=2, padx=40, rowspan=7, ipady=80)
        self.show.bind("<Button-1>", self.queryAll)


    def query_info(self, event):
        self.master.destroy()
        create_query_info()

    def add_info(self, event):
        create_add()

    def deleteInfo(self, event):
        messagebox.showinfo("title", "delete info")
        pass

    def modifyInfo(self, event):
        messagebox.showinfo("title", "modify info")
        pass

    def quiteSys(self):
        messagebox.showinfo("title", "quiteSys")
        self.master.destroy()
        pass

    def queryAll(self, event):
        messagebox.showinfo("title", "query all")
        pass

    # @staticmethod
    # def create_window():
    #     window = tk.Tk()
    #     window.title('添加信息')
    #     w = 600
    #     h = 500
    #     width = window.winfo_screenwidth()
    #     height = window.winfo_screenheight()
    #     x = (width - w) / 2
    #     y = (height - h) / 2
    #     window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    #     window.attributes("-alpha", 1)
    #     window.resizable(False, False)
    #     Application(master=window)
    #     # 需要加上这两句，否则背景颜色不生效
    #     style = ttk.Style()
    #     style.theme_use('classic')
    #     window.mainloop()
