import tkinter as tk
from tkinter import ttk

def create_query_info():
    global is_show
    is_show = False
    window = tk.Tk()
    window.title("信息查询")
    w = 600
    h = 500
    width = window.winfo_screenwidth()
    height = window.winfo_screenheight()
    x = (width - w) / 2
    y = (height - h) / 2
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.attributes("-alpha", 1)
    window.resizable(False, False)

    noVar = tk.StringVar()

    title = tk.Label(window, text="查询信息", font=("宋体", 30))
    title.pack(pady=30)

    title = tk.Label(window, text="请输入您要查询的编号:", font=("宋体", 15))
    title.pack(pady=10)

    no_entry = ttk.Entry(window, font=("宋体", 15), textvariable=noVar)
    no_entry.pack(pady=10)

    info_text = tk.Text(window, background='white', width=400, height=200)
    info_text.pack(pady=20)
    info_text.forget()

    btn_frm = tk.Frame(window)
    btn_frm.pack(pady=30, side=tk.BOTTOM)

    btn_back = tk.Button(btn_frm, text="返回", command=lambda: go_back(window))
    btn_back.pack(side=tk.LEFT)
    btn_query = tk.Button(btn_frm, text="查询", command=lambda: query(title, no_entry, info_text, window))
    btn_query.pack(side=tk.LEFT)


def go_back(window):
    if is_show:
        create_query_info()
        window.destroy()
    else:
        window.destroy()


def query(title, no_entry, info_text, window):
    is_show = True
    title.destroy()
    no_entry.destroy()
    info_text = tk.Text(window, background='white', width=60, height=40)
    info_text.pack(side=tk.TOP)
