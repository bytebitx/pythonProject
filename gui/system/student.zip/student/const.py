
USER_NAME = 'admin'
USER_PWD = 'admin'

COLLEGE = ["计算机学院", "美术学院", "体育学院"]