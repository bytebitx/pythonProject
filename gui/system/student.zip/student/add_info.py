import tkinter as tk
from tkinter import ttk

from gui.system.student.const import COLLEGE


def create_add():
    window = tk.Tk()
    window.title("添加信息")
    w = 600
    h = 500
    width = window.winfo_screenwidth()
    height = window.winfo_screenheight()
    x = (width - w) / 2
    y = (height - h) / 2
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.attributes("-alpha", 1)
    window.resizable(False, False)

    title_frm = tk.Frame(window)
    title_frm.pack()

    title = tk.Label(title_frm, text="添加信息", font=("宋体", 30))
    title.pack()

    noVar = tk.StringVar()
    nameVar = tk.StringVar()
    sexVar = tk.IntVar()
    ageVar = tk.StringVar()
    collegeVar = tk.StringVar()
    collegeVar.set(COLLEGE[0])
    progressVar = tk.StringVar()
    progressVar.set("")

    no_frm = tk.Frame(window)
    no_frm.pack()
    no = ttk.Label(no_frm, text="编号", font=("宋体", 15))
    no.pack(side=tk.LEFT, pady=30)
    no_entry = ttk.Entry(no_frm, font=("宋体", 15), textvariable=noVar)
    no_entry.pack(side=tk.LEFT, padx=15)

    name_frm = tk.Frame(window)
    name_frm.pack()
    name = ttk.Label(name_frm, text="姓名", font=("宋体", 15))
    name.pack(side=tk.LEFT)
    name_entry = ttk.Entry(name_frm, font=("宋体", 15), textvariable=nameVar)
    name_entry.pack(side=tk.LEFT, padx=15)

    sex_frm = tk.Frame(window)
    sex_frm.pack()
    sex = ttk.Label(sex_frm, text="性别", font=("宋体", 15), anchor='center')
    sex.pack(side=tk.LEFT, pady=30)

    sex_male_radiobtn = tk.Radiobutton(sex_frm, text="男", value=0,
                                       variable=sexVar, command=lambda: select_sex(sexVar))
    sex_male_radiobtn.pack(side=tk.LEFT, padx=50)
    sex_female_radiobtn = tk.Radiobutton(sex_frm, text="女", value=1,
                                         variable=sexVar, command=lambda: select_sex(sexVar))
    sex_female_radiobtn.pack(side=tk.LEFT, padx=27)

    age_frm = tk.Frame(window)
    age_frm.pack()
    age = ttk.Label(age_frm, text="年龄", font=("宋体", 15))
    age.pack(side=tk.LEFT)
    age_entry = ttk.Entry(age_frm, font=("宋体", 15), textvariable=ageVar)
    age_entry.pack(side=tk.LEFT, padx=15)

    colloge_frm = tk.Frame(window)
    colloge_frm.pack()
    college = ttk.Label(colloge_frm, text="学院", font=("宋体", 15))
    college.pack(side=tk.LEFT, pady=30)
    college_menu = tk.OptionMenu(colloge_frm, collegeVar, *COLLEGE)
    college_menu.pack(side=tk.LEFT, padx=65)

    progress_frm = tk.Frame(window)
    progress_frm.pack()
    progress = ttk.Label(progress_frm, text="专业", font=("宋体", 15))
    progress.pack(side=tk.LEFT)
    progress_entry = ttk.Entry(progress_frm, font=("宋体", 15), textvariable=progressVar)
    progress_entry.pack(side=tk.LEFT, padx=15)

    btn_frm = tk.Frame(window)
    btn_frm.pack()
    btn = ttk.Button(btn_frm, text="添加")
    btn.pack(side=tk.LEFT, pady=30)
    btn_back = tk.Button(btn_frm, text="返回", command=lambda: go_back(window))
    btn_back.pack(side=tk.LEFT, padx=65)


def select_sex(sexVar):
    print("sex = ", sexVar.get())


def go_back(window):
    window.destroy()
